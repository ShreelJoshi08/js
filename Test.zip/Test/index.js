const fs = require('fs');
const http = require('http');
const url = require('url');
// const slugify = require('slugify');


//// 1. Read all templates using read sync......

//   Code here............

// 2. Read JSON data file here....

// code here....


///console.log(dataObj)

// Server creation.......
const server = http.createServer((req, res) => {
  res.end(data);
// create route/path to home page, product page and api page

});

server.listen(9000, '127.0.0.1', () => {
  console.log('Listening to requests on port 9000');
});
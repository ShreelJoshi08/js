const calculateWeightLostInAMonth = (cycling, running, swimming, extraCalorieInTake) => {
    if (cycling <= 0 || running < 0 || swimming < 0 || extraCalorieInTake < 0) {
        return -1;
    }
    if (cycling === 0 || running === 0 || swimming === 0) {
        return -1;
    }
    const weeksInMonth = 4;
    const sessionsPerActivity = weeksInMonth;
    const minutesPerSession = 60;
    const factor = minutesPerSession / 30;
    const cyclingCalories = cycling * factor * sessionsPerActivity;
    const runningCalories = running * factor * sessionsPerActivity;
    const swimmingCalories = swimming * factor * sessionsPerActivity;
    const totalBurned = cyclingCalories + runningCalories + swimmingCalories;
    const totalExtra = extraCalorieInTake * 30;
    const netCalories = totalBurned - totalExtra;
    const weightLostInAMonth = netCalories / 1000;
    return Math.round(weightLostInAMonth * 10) / 10;
}

module.exports = calculateWeightLostInAMonth


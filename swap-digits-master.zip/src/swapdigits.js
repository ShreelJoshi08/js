function swapDigits(n) {
    if (n < 0) return 0;
    let digits = n.toString().split('');
    let len = digits.length;
    let start = 0;

    if (len % 2 !== 0) {
        start = 1;
    }

    for (let i = start; i < len - 1; i += 2) {
        let temp = digits[i];
        digits[i] = digits[i + 1];
        digits[i + 1] = temp;
    }

    return parseInt(digits.join(''), 10);
}

module.exports = swapDigits;

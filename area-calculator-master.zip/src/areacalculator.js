const pi = 3.14;

const calculateArea = (choice, side, length, breadth, radius) => {
    let area = 0.0;
    if (choice === 'square') {
        if (side == null || isNaN(side)) return -1;
        area = 4 * side;
    } else if (choice === 'rectangle') {
        if (length == null || breadth == null || isNaN(length) || isNaN(breadth)) return -1;
        area = length * breadth;
    } else if (choice === 'circle') {
        if (radius == null || isNaN(radius)) return -1;
        area = pi * radius * radius;
    } else {
        return -1;
    }
    return area;
}
module.exports = { calculateArea }

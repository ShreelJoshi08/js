const StringManipulation = require('./src/StringManipulation');

// Sample string for testing
const sampleString = "Hi, welcome to learning programming";

console.log("=== String Manipulation Functions Demo ===\n");

// 1. Count characters
console.log("1. Count Characters:");
console.log(`Input: "${sampleString}"`);
console.log(`Character count: ${StringManipulation.countCharacters(sampleString)}`);
console.log();

// 2. Count vowels
console.log("2. Count Vowels:");
console.log(`Input: "${sampleString}"`);
console.log(`Vowel count: ${StringManipulation.countVowels(sampleString)}`);
console.log();

// 3. Check existence of string
console.log("3. Check String Existence:");
console.log(`Input: "${sampleString}"`);
console.log(`Contains "welcome": ${StringManipulation.checkExistenceOfStr(sampleString, "welcome")}`);
console.log(`Contains "hello": ${StringManipulation.checkExistenceOfStr(sampleString, "hello")}`);
console.log();

// 4. Replace word
console.log("4. Replace Word:");
console.log(`Input: "${sampleString}"`);
console.log(`Replace "programming" with "platform": ${StringManipulation.replaceWord(sampleString, "programming", "platform")}`);
console.log();

// 5. Convert to Title Case
console.log("5. Title Case Conversion:");
console.log(`Input: "${sampleString}"`);
console.log(`Title case: ${StringManipulation.titleCaseConversion(sampleString)}`);
console.log();

// 6. Find longest word
console.log("6. Find Longest Word:");
console.log(`Input: "${sampleString}"`);
console.log(`Longest word: ${StringManipulation.findLongestWord(sampleString)}`);
console.log();

// Additional test cases
console.log("=== Additional Test Cases ===\n");

const testString = "Programming is fun";
console.log(`Test string: "${testString}"`);
console.log(`Character count: ${StringManipulation.countCharacters(testString)}`);
console.log(`Vowel count: ${StringManipulation.countVowels(testString)}`);
console.log(`Contains "gram": ${StringManipulation.checkExistenceOfStr(testString, "gram")}`);
console.log(`Replace "Programming" with "Platform": ${StringManipulation.replaceWord(testString, "Programming", "Platform")}`);
console.log(`Title case: ${StringManipulation.titleCaseConversion(testString)}`);
console.log(`Longest word: ${StringManipulation.findLongestWord(testString)}`); 
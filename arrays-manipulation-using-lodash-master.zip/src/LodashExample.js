
//import the lodash module
const _ = require('lodash');

//Create a function to find a maximum value from number array.
function findMaxValue(numbers) {
  return _.max(numbers);
}

//Create a function to return all values from numbers array 
//which are greater than the second parameter.​
function filterValues(numbers, threshold) {
  return _.filter(numbers, num => num > threshold);
}

//Create a function to return all values of employeeName array in capital letters.
function nameInCapital(employeeNames) {
  return _.map(employeeNames, name => _.toUpper(name));
}

module.exports = {
  findMaxValue,
  filterValues,
  nameInCapital,
}

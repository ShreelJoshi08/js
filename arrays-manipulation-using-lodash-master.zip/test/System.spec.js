const { expect } = require("chai");
const System = require("../src/System");

describe("Testing System module methods", function () {
  it("Testing getOSName function", function () {
    const osName = System.getOSName();
    expect(osName).to.be.a('string');
    expect(osName.length).to.be.greaterThan(0);
  });

  it("Testing getFreeMemory function", function () {
    const freeMemory = System.getFreeMemory();
    expect(freeMemory).to.be.a('number');
    expect(freeMemory).to.be.greaterThan(0);
  });

  it("Testing getCurrentUser function", function () {
    const currentUser = System.getCurrentUser();
    expect(currentUser).to.be.an('object');
    expect(currentUser).to.have.property('username');
  });

  it("Testing getHostName function", function () {
    const hostName = System.getHostName();
    expect(hostName).to.be.a('string');
    expect(hostName.length).to.be.greaterThan(0);
  });

  it("Testing getCPUDetails function", function () {
    const cpuDetails = System.getCPUDetails();
    expect(cpuDetails).to.be.an('array');
    expect(cpuDetails.length).to.be.greaterThan(0);
    expect(cpuDetails[0]).to.have.property('model');
  });
}); 